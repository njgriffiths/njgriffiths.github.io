(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],[
/* 0 */,
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(1);
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(0);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/vanilla-lazyload/dist/lazyload.min.js
var lazyload_min = __webpack_require__(2);
var lazyload_min_default = /*#__PURE__*/__webpack_require__.n(lazyload_min);

// EXTERNAL MODULE: ./src/css/main.css
var main = __webpack_require__(4);

// EXTERNAL MODULE: ./src/css/normalize.css
var normalize = __webpack_require__(5);

// CONCATENATED MODULE: ./src/data/image-list.js
var imageList = ['bc-election.jpg', 'print-thumbnail.jpg', 'brewery-bike-tour.jpg', 'second-line.jpg', 'calais.jpg', 'shrimp-sheds.jpg', 'covid-20k.jpg', 'slave-fishermen.jpg', 'daily-360.png', 'suite-life.jpg', 'eln-2012.jpg', 'taser-illo.jpg', 'energize-bridgewater.jpg', 'trading-signals.jpg', 'focus-dprk.jpg', 'transgender-youth.jpg', 'honduras.jpg', 'two-koreas-1.jpg', 'honor-killings.jpg', 'two-koreas-2.jpg', 'instagram-parks.jpg', 'uss-gerald-ford.jpg', 'medal.jpg', 'vpd-budget.jpg', 'nimrud-riches.jpg', 'wc-goals.jpg', 'old-world.jpg', 'weegee.jpg', 'paektu.jpg', 'worldport.jpg'];
/* harmony default export */ var image_list = (imageList);
// CONCATENATED MODULE: ./src/images/placeholder.png
/* harmony default export */ var placeholder = (__webpack_require__.p + "assets/placeholder.bd4ea0b3.png");
// CONCATENATED MODULE: ./src/index.js


// JS
 // CSS


 // IMG


 // JS

var init = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee() {
    var myLazyLoad;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            myLazyLoad = new lazyload_min_default.a();

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function init() {
    return _ref.apply(this, arguments);
  };
}();

init();

/***/ })
],[[6,1,2]]]);