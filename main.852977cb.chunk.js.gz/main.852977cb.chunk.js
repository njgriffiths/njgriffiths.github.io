(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],[
/* 0 */,
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),
/* 8 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(1);
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);

// EXTERNAL MODULE: ./node_modules/@babel/runtime/regenerator/index.js
var regenerator = __webpack_require__(0);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/vanilla-lazyload/dist/lazyload.min.js
var lazyload_min = __webpack_require__(2);
var lazyload_min_default = /*#__PURE__*/__webpack_require__.n(lazyload_min);

// EXTERNAL MODULE: ./src/css/main.css
var main = __webpack_require__(5);

// EXTERNAL MODULE: ./src/css/normalize.css
var normalize = __webpack_require__(6);

// EXTERNAL MODULE: ./src/css/photoswipe.css
var photoswipe = __webpack_require__(7);

// CONCATENATED MODULE: ./src/images/placeholder.png
/* harmony default export */ var placeholder = (__webpack_require__.p + "images/placeholder.png");
// CONCATENATED MODULE: ./src/images/bc-election.jpg
/* harmony default export */ var bc_election = (__webpack_require__.p + "images/bc-election.jpg");
// CONCATENATED MODULE: ./src/images/print-thumbnail.jpg
/* harmony default export */ var print_thumbnail = (__webpack_require__.p + "images/print-thumbnail.jpg");
// CONCATENATED MODULE: ./src/images/brewery-bike-tour.jpg
/* harmony default export */ var brewery_bike_tour = (__webpack_require__.p + "images/brewery-bike-tour.jpg");
// CONCATENATED MODULE: ./src/images/second-line.jpg
/* harmony default export */ var second_line = (__webpack_require__.p + "images/second-line.jpg");
// CONCATENATED MODULE: ./src/images/calais.jpg
/* harmony default export */ var calais = (__webpack_require__.p + "images/calais.jpg");
// CONCATENATED MODULE: ./src/images/shrimp-sheds.jpg
/* harmony default export */ var shrimp_sheds = (__webpack_require__.p + "images/shrimp-sheds.jpg");
// CONCATENATED MODULE: ./src/images/covid-20k.jpg
/* harmony default export */ var covid_20k = (__webpack_require__.p + "images/covid-20k.jpg");
// CONCATENATED MODULE: ./src/images/slave-fishermen.jpg
/* harmony default export */ var slave_fishermen = (__webpack_require__.p + "images/slave-fishermen.jpg");
// CONCATENATED MODULE: ./src/images/daily-360.png
/* harmony default export */ var daily_360 = (__webpack_require__.p + "images/daily-360.png");
// CONCATENATED MODULE: ./src/images/suite-life.jpg
/* harmony default export */ var suite_life = (__webpack_require__.p + "images/suite-life.jpg");
// CONCATENATED MODULE: ./src/images/eln-2012.jpg
/* harmony default export */ var eln_2012 = (__webpack_require__.p + "images/eln-2012.jpg");
// CONCATENATED MODULE: ./src/images/taser-illo.jpg
/* harmony default export */ var taser_illo = (__webpack_require__.p + "images/taser-illo.jpg");
// CONCATENATED MODULE: ./src/images/energize-bridgewater.jpg
/* harmony default export */ var energize_bridgewater = (__webpack_require__.p + "images/energize-bridgewater.jpg");
// CONCATENATED MODULE: ./src/images/trading-signals.jpg
/* harmony default export */ var trading_signals = (__webpack_require__.p + "images/trading-signals.jpg");
// CONCATENATED MODULE: ./src/images/focus-dprk.jpg
/* harmony default export */ var focus_dprk = (__webpack_require__.p + "images/focus-dprk.jpg");
// CONCATENATED MODULE: ./src/images/transgender-youth.jpg
/* harmony default export */ var transgender_youth = (__webpack_require__.p + "images/transgender-youth.jpg");
// CONCATENATED MODULE: ./src/images/honduras.jpg
/* harmony default export */ var honduras = (__webpack_require__.p + "images/honduras.jpg");
// CONCATENATED MODULE: ./src/images/honor-killings.jpg
/* harmony default export */ var honor_killings = (__webpack_require__.p + "images/honor-killings.jpg");
// CONCATENATED MODULE: ./src/images/two-koreas-2.jpg
/* harmony default export */ var two_koreas_2 = (__webpack_require__.p + "images/two-koreas-2.jpg");
// CONCATENATED MODULE: ./src/images/instagram-parks.jpg
/* harmony default export */ var instagram_parks = (__webpack_require__.p + "images/instagram-parks.jpg");
// CONCATENATED MODULE: ./src/images/uss-gerald-ford.jpg
/* harmony default export */ var uss_gerald_ford = (__webpack_require__.p + "images/uss-gerald-ford.jpg");
// CONCATENATED MODULE: ./src/images/medal.jpg
/* harmony default export */ var medal = (__webpack_require__.p + "images/medal.jpg");
// CONCATENATED MODULE: ./src/images/vpd-budget.jpg
/* harmony default export */ var vpd_budget = (__webpack_require__.p + "images/vpd-budget.jpg");
// CONCATENATED MODULE: ./src/images/nimrud-riches.jpg
/* harmony default export */ var nimrud_riches = (__webpack_require__.p + "images/nimrud-riches.jpg");
// CONCATENATED MODULE: ./src/images/wc-goals.jpg
/* harmony default export */ var wc_goals = (__webpack_require__.p + "images/wc-goals.jpg");
// CONCATENATED MODULE: ./src/images/old-world.jpg
/* harmony default export */ var old_world = (__webpack_require__.p + "images/old-world.jpg");
// CONCATENATED MODULE: ./src/images/weegee.jpg
/* harmony default export */ var weegee = (__webpack_require__.p + "images/weegee.jpg");
// CONCATENATED MODULE: ./src/images/paektu.jpg
/* harmony default export */ var paektu = (__webpack_require__.p + "images/paektu.jpg");
// CONCATENATED MODULE: ./src/images/worldport.jpg
/* harmony default export */ var worldport = (__webpack_require__.p + "images/worldport.jpg");
// CONCATENATED MODULE: ./src/images/urban-forest.jpg
/* harmony default export */ var urban_forest = (__webpack_require__.p + "images/urban-forest.jpg");
// CONCATENATED MODULE: ./src/images/heat-islands.jpg
/* harmony default export */ var heat_islands = (__webpack_require__.p + "images/heat-islands.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/oly-anniversary.jpg
/* harmony default export */ var oly_anniversary = (__webpack_require__.p + "images/oly-anniversary.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/poli-tweets.jpg
/* harmony default export */ var poli_tweets = (__webpack_require__.p + "images/poli-tweets.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/isp-complaints.jpg
/* harmony default export */ var isp_complaints = (__webpack_require__.p + "images/isp-complaints.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/ballot-data.jpg
/* harmony default export */ var ballot_data = (__webpack_require__.p + "images/ballot-data.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/ethnicity-map.jpg
/* harmony default export */ var ethnicity_map = (__webpack_require__.p + "images/ethnicity-map.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/public-sector-salaries.jpg
/* harmony default export */ var public_sector_salaries = (__webpack_require__.p + "images/public-sector-salaries.jpg");
// CONCATENATED MODULE: ./src/index.js



// JS
__webpack_require__(4);

 // CSS



 // IMG - THUMBS
































 // IMG - PRINT






 // JS

var init = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee() {
    var myLazyLoad, lightbox, openLightbox;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            myLazyLoad = new lazyload_min_default.a(); // lightbox for print gfx

            lightbox = new FsLightbox();
            openLightbox = document.getElementById('image-container');
            lightbox.props.sources = [public_sector_salaries, isp_complaints, ballot_data, poli_tweets, ethnicity_map, oly_anniversary];
            openLightbox.addEventListener('click', function () {
              lightbox.open();
            });

          case 5:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function init() {
    return _ref.apply(this, arguments);
  };
}();

init();

/***/ })
],[[8,1,2]]]);