(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],[
/* 0 */,
/* 1 */,
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),
/* 5 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ./node_modules/vanilla-lazyload/dist/lazyload.min.js
var lazyload_min = __webpack_require__(0);
var lazyload_min_default = /*#__PURE__*/__webpack_require__.n(lazyload_min);

// EXTERNAL MODULE: ./src/css/main.css
var main = __webpack_require__(2);

// EXTERNAL MODULE: ./src/css/normalize.css
var normalize = __webpack_require__(3);

// EXTERNAL MODULE: ./src/css/photoswipe.css
var photoswipe = __webpack_require__(4);

// CONCATENATED MODULE: ./src/images/placeholder.png
/* harmony default export */ var placeholder = (__webpack_require__.p + "images/placeholder.png");
// CONCATENATED MODULE: ./src/images/bc-election.jpg
/* harmony default export */ var bc_election = (__webpack_require__.p + "images/bc-election.jpg");
// CONCATENATED MODULE: ./src/images/print-thumbnail.jpg
/* harmony default export */ var print_thumbnail = (__webpack_require__.p + "images/print-thumbnail.jpg");
// CONCATENATED MODULE: ./src/images/brewery-bike-tour.jpg
/* harmony default export */ var brewery_bike_tour = (__webpack_require__.p + "images/brewery-bike-tour.jpg");
// CONCATENATED MODULE: ./src/images/second-line.jpg
/* harmony default export */ var second_line = (__webpack_require__.p + "images/second-line.jpg");
// CONCATENATED MODULE: ./src/images/calais.jpg
/* harmony default export */ var calais = (__webpack_require__.p + "images/calais.jpg");
// CONCATENATED MODULE: ./src/images/covid-20k.jpg
/* harmony default export */ var covid_20k = (__webpack_require__.p + "images/covid-20k.jpg");
// CONCATENATED MODULE: ./src/images/slave-fishermen.jpg
/* harmony default export */ var slave_fishermen = (__webpack_require__.p + "images/slave-fishermen.jpg");
// CONCATENATED MODULE: ./src/images/daily-360.png
/* harmony default export */ var daily_360 = (__webpack_require__.p + "images/daily-360.png");
// CONCATENATED MODULE: ./src/images/suite-life.jpg
/* harmony default export */ var suite_life = (__webpack_require__.p + "images/suite-life.jpg");
// CONCATENATED MODULE: ./src/images/eln-2012.jpg
/* harmony default export */ var eln_2012 = (__webpack_require__.p + "images/eln-2012.jpg");
// CONCATENATED MODULE: ./src/images/taser-illo.jpg
/* harmony default export */ var taser_illo = (__webpack_require__.p + "images/taser-illo.jpg");
// CONCATENATED MODULE: ./src/images/transgender-youth.jpg
/* harmony default export */ var transgender_youth = (__webpack_require__.p + "images/transgender-youth.jpg");
// CONCATENATED MODULE: ./src/images/honduras.jpg
/* harmony default export */ var honduras = (__webpack_require__.p + "images/honduras.jpg");
// CONCATENATED MODULE: ./src/images/honor-killings.jpg
/* harmony default export */ var honor_killings = (__webpack_require__.p + "images/honor-killings.jpg");
// CONCATENATED MODULE: ./src/images/two-koreas-2.jpg
/* harmony default export */ var two_koreas_2 = (__webpack_require__.p + "images/two-koreas-2.jpg");
// CONCATENATED MODULE: ./src/images/instagram-parks.jpg
/* harmony default export */ var instagram_parks = (__webpack_require__.p + "images/instagram-parks.jpg");
// CONCATENATED MODULE: ./src/images/uss-gerald-ford.jpg
/* harmony default export */ var uss_gerald_ford = (__webpack_require__.p + "images/uss-gerald-ford.jpg");
// CONCATENATED MODULE: ./src/images/medal.jpg
/* harmony default export */ var medal = (__webpack_require__.p + "images/medal.jpg");
// CONCATENATED MODULE: ./src/images/vpd-budget.jpg
/* harmony default export */ var vpd_budget = (__webpack_require__.p + "images/vpd-budget.jpg");
// CONCATENATED MODULE: ./src/images/nimrud-riches.jpg
/* harmony default export */ var nimrud_riches = (__webpack_require__.p + "images/nimrud-riches.jpg");
// CONCATENATED MODULE: ./src/images/yucho.jpg
/* harmony default export */ var yucho = (__webpack_require__.p + "images/yucho.jpg");
// CONCATENATED MODULE: ./src/images/old-world.jpg
/* harmony default export */ var old_world = (__webpack_require__.p + "images/old-world.jpg");
// CONCATENATED MODULE: ./src/images/weegee.jpg
/* harmony default export */ var weegee = (__webpack_require__.p + "images/weegee.jpg");
// CONCATENATED MODULE: ./src/images/paektu.jpg
/* harmony default export */ var paektu = (__webpack_require__.p + "images/paektu.jpg");
// CONCATENATED MODULE: ./src/images/worldport.jpg
/* harmony default export */ var worldport = (__webpack_require__.p + "images/worldport.jpg");
// CONCATENATED MODULE: ./src/images/urban-forest.jpg
/* harmony default export */ var urban_forest = (__webpack_require__.p + "images/urban-forest.jpg");
// CONCATENATED MODULE: ./src/images/heat-islands.jpg
/* harmony default export */ var heat_islands = (__webpack_require__.p + "images/heat-islands.jpg");
// CONCATENATED MODULE: ./src/images/candidate-lookup.jpg
/* harmony default export */ var candidate_lookup = (__webpack_require__.p + "images/candidate-lookup.jpg");
// CONCATENATED MODULE: ./src/images/iio-charges.jpg
/* harmony default export */ var iio_charges = (__webpack_require__.p + "images/iio-charges.jpg");
// CONCATENATED MODULE: ./src/images/seniors-rent.jpg
/* harmony default export */ var seniors_rent = (__webpack_require__.p + "images/seniors-rent.jpg");
// CONCATENATED MODULE: ./src/images/nonbinary-comic.jpg
/* harmony default export */ var nonbinary_comic = (__webpack_require__.p + "images/nonbinary-comic.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/oly-anniversary.jpg
/* harmony default export */ var oly_anniversary = (__webpack_require__.p + "images/oly-anniversary.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/poli-tweets.jpg
/* harmony default export */ var poli_tweets = (__webpack_require__.p + "images/poli-tweets.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/isp-complaints.jpg
/* harmony default export */ var isp_complaints = (__webpack_require__.p + "images/isp-complaints.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/ballot-data.jpg
/* harmony default export */ var ballot_data = (__webpack_require__.p + "images/ballot-data.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/ethnicity-map.jpg
/* harmony default export */ var ethnicity_map = (__webpack_require__.p + "images/ethnicity-map.jpg");
// CONCATENATED MODULE: ./src/images/print-gfx/public-sector-salaries.jpg
/* harmony default export */ var public_sector_salaries = (__webpack_require__.p + "images/public-sector-salaries.jpg");
// CONCATENATED MODULE: ./src/images/wildfire-map.jpg
/* harmony default export */ var wildfire_map = (__webpack_require__.p + "images/wildfire-map.jpg");
// CONCATENATED MODULE: ./src/index.js
// JS
__webpack_require__(1);


// CSS




// IMG - THUMBS






// import shrimp_sheds from './images/shrimp-sheds.jpg';






// import energize_bridgewater from './images/energize-bridgewater.jpg';
// import trading_signals from './images/trading-signals.jpg';
// import focus_dprk from './images/focus-dprk.jpg';





















// IMG - PRINT






// IMG – THUMBS



// JS
const init = async () => {
  const myLazyLoad = new lazyload_min_default.a();

  // lightbox for print gfx
  const lightbox = new FsLightbox();
  const openLightbox = document.getElementById('image-container');
  lightbox.props.sources = [public_sector_salaries, poli_tweets, ethnicity_map, oly_anniversary, isp_complaints, ballot_data];
  openLightbox.addEventListener('click', () => {
    lightbox.open();
  });
};
init();

/***/ })
],[[5,1,2]]]);